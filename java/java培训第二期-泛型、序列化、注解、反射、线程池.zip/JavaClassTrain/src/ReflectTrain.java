import com.sun.org.apache.bcel.internal.generic.TargetLostException;

import java.lang.reflect.Method;

public class ReflectTrain {
    public static void main(String args[]) throws NoSuchMethodException, Exception {
        Car car = new Car();
        car.setPrice(1000000000);
        Method method = car.getClass().getMethod("isExpensive");
        System.out.println(method.invoke(car));
    }
}
class Car{
    private String name;
    private int price;

    public boolean isExpensive(){
        if(this.price > 10000){
            return true;
        }
        return false;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
