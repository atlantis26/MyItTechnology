import java.lang.annotation.*;

public class AnnotationTrain {
    public static void main(String args[]){
        User user = new User();
        Table table = (Table) user.getClass().getAnnotation(Table.class);
        System.out.println(table.value());
    }
}

/***
 * 数据库表的注解
 *  */
@Target({ElementType.TYPE}) //设置作用域为类 接口
@Retention(RetentionPolicy.RUNTIME) //设置生命周期为运行时
@interface Table {
    String value();  //表名
}

@Table(value="user")
class User{
    private String name;
}
