import java.util.ArrayList;
import java.util.List;

public class TClassTrain {
    public static void main(String args[]){
        List<String> list = new ArrayList<>();
//        list.add(1);
        list.add("a");
        list.add("b");
        list.add("c");
        System.out.println(list);

        //泛化类
        GenericClass<String> genericClass1 = new GenericClass<>();
        genericClass1.setData("dddd");
        System.out.println(genericClass1.getData());

        GenericClass<Integer> genericClass2 = new GenericClass<>();
        genericClass2.setData(1);
        System.out.println(genericClass2.getData());

    }

}
class GenericClass<T>{
    private T data;
    public void setData(T data){
        this.data = data;
    }
    public T getData(){
        return this.data;
    }
}