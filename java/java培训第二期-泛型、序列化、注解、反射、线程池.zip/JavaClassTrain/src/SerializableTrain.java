import java.io.*;

public class SerializableTrain {
    public static void main(String args[]) throws FileNotFoundException, IOException, Exception{
        People people = new People();
        people.setName("tangke");
        people.setAge(18);

        ObjectOutputStream objectOutputStream = new ObjectOutputStream(new FileOutputStream(new File("1.txt")));
        objectOutputStream.writeObject(people);

        ObjectInputStream objectInputStream = new ObjectInputStream(new FileInputStream(new File("1.txt")));
        People people1 = (People) objectInputStream.readObject();
        System.out.println(people1);
    }
}

class People implements Serializable {
    private String name;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
    @Override
    public String toString(){
        return "name: " + this.getName() + " age: " + this.getAge();
    }
}
